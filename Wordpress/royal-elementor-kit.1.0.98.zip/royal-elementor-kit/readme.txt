=== Royal Elementor Kit ===

Author: WP Royal
Requires at least: WordPress 4.7+
Tested up to: WordPress 6.1.1
Version: 1.0.98
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.en.html
Tags: blog, e-commerce, one-column, custom-background, custom-colors, full-width-template, custom-menu, custom-logo, featured-images, sticky-post, theme-options, threaded-comments, translation-ready


== Description ==

Truly all in one Solution For Elementor Lovers. 30+ Elementor Templates KIT, 50+ Professional Elementor Widgets, Elementor theme builder, Elementor Popup Builder, Elementor Premade blocks and many other cool features like Sticky Header, Particle effects, parallax backgrounds and many other elementor addons. Simple Install the theme, click on - Get Started with Templates Kit button and that's it. Very easy to use even for WordPress beginners or professionals. All In one Elementor Solution which outranks all other Elementor themes and Elementor addons. ########### TEMPLATES INCLUDED: Elementor Blog Template, Elementor Magazine Blog Template, Elementor Food Blog Template, Elementor Travel Blog Template, Elementor Portfolio Template, Elementor NFT Template, Elementor Pizza Restaurant Template, Elementor Travel Blogger & Influencer Template, Elementor Cybersecurity Template, Elementor Photographer Portfolio Template, Elementor Crypto Currency Template, Elementor Skin Care Template, Elementor Lawyer Template, Elementor Medical Template, Elementor Digital Agency Template, Elementor Drone Template, Elementro Architecture Template, Elementor Food Delivery Template, Elementor Construction Template, Elementor IT Technology Template, Elementor Real Estate Template, Elementor Restaurant Template, Elementor Wine Bar & Restaurant Template, Elementor Wedding Template & other beautiful elementor business templates. All these templates are created with elementor page builder. Theme Demo Page: https://royal-elementor-addons.com/royal-elementor-kit/


== Copyright ==

Royal Elementor Kit, Copyright 2022 wp-royal.com
It is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.


Royal Elementor Kit bundles the following third-party resources:

Image Credits (screenshot.png):

Hand-drawn illustrations used are created by WP Royal Team and released under Creative Commons ( CC0 ) License.

https://royal-elementor-addons.com/wp-content/uploads/wporg-theme-imgs/illustration1.PNG
https://royal-elementor-addons.com/wp-content/uploads/wporg-theme-imgs/illustration2.PNG
https://royal-elementor-addons.com/wp-content/uploads/wporg-theme-imgs/illustration3.PNG
https://royal-elementor-addons.com/wp-content/uploads/wporg-theme-imgs/illustration4.PNG
https://royal-elementor-addons.com/wp-content/uploads/wporg-theme-imgs/illustration5.PNG
