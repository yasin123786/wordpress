</div><!-- end main-container -->
</div><!-- end page-area -->

<?php do_action('enwoo_generate_footer'); ?>

</div><!-- end page-wrap -->

<?php wp_footer(); ?>

</body>
</html>
