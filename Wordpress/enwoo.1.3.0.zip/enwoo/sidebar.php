<?php if (is_active_sidebar('enwoo-right-sidebar')) { ?>
    <aside id="sidebar" class="col-md-3">
        <?php dynamic_sidebar('enwoo-right-sidebar'); ?>
    </aside>
<?php 
}
