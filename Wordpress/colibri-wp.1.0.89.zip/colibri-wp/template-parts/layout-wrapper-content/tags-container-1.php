<div data-colibri-id="432-m15" class="h-row-container gutters-row-lg-0 gutters-row-md-0 gutters-row-0 gutters-row-v-lg-0 gutters-row-v-md-0 gutters-row-v-0 style-555 style-local-432-m15 position-relative">
  <div class="h-row justify-content-lg-center justify-content-md-center justify-content-center align-items-lg-center align-items-md-center align-items-center gutters-col-lg-0 gutters-col-md-0 gutters-col-0 gutters-col-v-lg-0 gutters-col-v-md-0 gutters-col-v-0">
    <div class="h-column h-column-container d-flex h-col-lg-auto h-col-md-auto h-col-auto align-self-lg-center align-self-md-center align-self-center style-556-outer style-local-432-m16-outer">
      <div data-colibri-id="432-m16" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-0 v-inner-md-0 v-inner-0 style-556 style-local-432-m16 position-relative">
        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-auto align-self-lg-center align-self-md-center align-self-center">
          <div data-colibri-id="432-m17" class="h-text h-text-component style-557 style-local-432-m17 position-relative h-element">
            <div>
              <p>
                <?php esc_html_e('Tags:','colibri-wp'); ?>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="h-column h-column-container d-flex h-col-lg h-col-md h-col align-self-lg-center align-self-md-center align-self-center style-558-outer style-local-432-m18-outer">
      <div data-colibri-id="432-m18" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-0 v-inner-md-0 v-inner-0 style-558 style-local-432-m18 position-relative">
        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-center align-self-md-center align-self-center">
          <div data-colibri-id="432-m19" class="h-blog-tags empty-preview style-559 style-local-432-m19 position-relative h-element">
            <div class="h-global-transition-all">
              <?php colibriwp_post_tags(array (
                'prefix' => '',
              )); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
