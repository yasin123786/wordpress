<div data-colibri-id="7-h28" class="h-global-transition-all h-heading style-22 style-local-7-h28 position-relative h-element">
  <?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
  <h1>
    <?php $component->printTitle(); ?>
  </h1>
</div>
