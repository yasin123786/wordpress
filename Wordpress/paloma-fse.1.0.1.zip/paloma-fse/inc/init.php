<?php
/**
 * Bootstrap file to initiate core files.
 */
include 'core/styles.php';
include 'core/pattern-category.php';
include 'core/template-functions.php';
include 'core/theme-info.php';
