<?php
/**
 * VK Helpers Config
 */

if ( ! class_exists( 'VK_Helpers' ) ) {
	require_once dirname( __FILE__ ) . '/package/class-vk-helpers.php';
}
