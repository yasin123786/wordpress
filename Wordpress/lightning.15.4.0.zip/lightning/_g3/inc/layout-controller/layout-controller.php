<?php
require get_parent_theme_file_path( '/inc/layout-controller/admin-post-meta.php' );
require get_parent_theme_file_path( '/inc/layout-controller/admin-customize.php' );
require get_parent_theme_file_path( '/inc/layout-controller/admin-customize-column.php' );
require get_parent_theme_file_path( '/inc/layout-controller/admin-customize-sidebar.php' );
require get_parent_theme_file_path( '/inc/layout-controller/functions-layout-controll.php' );
